.. _bicluster_examples:

Biclustering
------------

Examples concerning the :mod:`sklearn.cluster.bicluster` module.
