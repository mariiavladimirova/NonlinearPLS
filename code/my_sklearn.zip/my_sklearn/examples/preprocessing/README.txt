.. _preprocessing_examples:

Preprocessing
-------------

Examples concerning the :mod:`sklearn.preprocessing` module.
